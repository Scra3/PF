GROUPE : MR Guerroudj MR BERTOLINI

Question 1,2,3 résolu 
il manque la question 4 et l'exécutable
